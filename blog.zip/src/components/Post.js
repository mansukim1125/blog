'use strict';

import AbstractComponent from './Abstract';

import Posts from '../api/Posts';
import marked from 'marked';

export default class PostComponent extends AbstractComponent {
    async mount() {
        this.mountPosId = 'main-container';
        await this.getPost();
        super.mount();
    }
    async getPost() {
        const post = await Posts.get(this.param.postId);
        this.post = post;
        this.post.content = this.post.content.replace(/---\n(.+\n)+---/, '');
        this.compiled = marked(this.post.content);
    }
    getHTML() {
        return `
            <header id="posts-header">
                <h1>${this.post.name.replace(/\.md$/, '')}</h1>
            </header>
            <div id="post">
                <p>${this.compiled}</p>
            </div>
        `;
    }
}
