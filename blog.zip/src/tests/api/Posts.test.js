'use strict';

const Posts = require('../../api/Posts');

describe('test about Posts', () => {
    test('get posts', async () => {
        await Posts.get();
    });
});
